package aaa.bbb.ccc07

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView

class MainActivity : AppCompatActivity() {

    lateinit var image1: ImageView
    lateinit var image2: ImageView
    lateinit var image3: ImageView
    lateinit var image4: ImageView
    lateinit var image5: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        image1 = findViewById(R.id.circularImageView)
        image1.setOnClickListener {
            val intent = Intent(this, Stockholm::class.java)
            startActivity(intent)
        }

        image2 = findViewById(R.id.circularImageView2)
        image2.setOnClickListener {
            val intent = Intent(this, Helsinki::class.java)
            startActivity(intent)
        }

        image3 = findViewById(R.id.circularImageView3)
        image3.setOnClickListener {
            val intent = Intent(this, Oslo::class.java)
            startActivity(intent)
        }

        image4 = findViewById(R.id.circularImageView4)
        image4.setOnClickListener {
            val intent = Intent(this, Kopengagen::class.java)
            startActivity(intent)
        }

        image5 = findViewById(R.id.stt)
        image5.setOnClickListener {
            val intent = Intent(this, Settings::class.java)
            startActivity(intent)
        }
    }
}
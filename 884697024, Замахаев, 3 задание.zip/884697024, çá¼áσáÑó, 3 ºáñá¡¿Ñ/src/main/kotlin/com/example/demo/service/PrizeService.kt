package com.example.demo.service

import com.example.demo.system.*
import org.springframework.stereotype.Service

@Service
class PrizeService(private val prizeRepository: PrizeRepository) {
    fun all(): Iterable<Prize> = prizeRepository.findAll()

    fun get(id: Long): Prize = prizeRepository.findOne(id)

    fun add(product: Prize): Prize = prizeRepository.save(product)

    fun edit(id: Long, prize: Prize): Prize = prizeRepository.save(prize.copy(id = id))

    fun remove(id: Long) = prizeRepository.delete(id)
}
package com.example.demo.service

import com.example.demo.system.Promo
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("Промоакция")
class PromoController(private val promoService: PromoService) {
    @GetMapping
    fun index() = promoService.all()

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    fun create(@RequestBody promo: Promo) = promoService.add(promo)

    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.FOUND)
    fun read(@PathVariable id: Long) = promoService.get(id)

    @PutMapping("{id}")
    fun update(@PathVariable id: Long, @RequestBody promo: Promo) = promoService.edit(id, promo)

    @DeleteMapping("{id}")
    fun delete(@PathVariable id: Long) = promoService.remove(id)
}
package com.example.demo.system

import javax.persistence.*
import com.fasterxml.jackson.annotation.*

@Entity
@Table(name = "Приз")
data class Prize(

    @JsonProperty("description")
    @Column(name = "description", length = 200)
    val description: String = "",

    @Id
    @JsonProperty("id")
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Long = 0L
)
package com.example.demo.service

import com.example.demo.system.Raffle

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("Приз")
class RaffleController(private val raffleService: RaffleService) {
    @GetMapping
    fun index() = raffleService.all()

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    fun create(@RequestBody raffle: Raffle) = raffleService.add(raffle)

    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.FOUND)
    fun read(@PathVariable id: Long) = raffleService.get(id)

    @PutMapping("{id}")
    fun update(@PathVariable id: Long, @RequestBody raffle: Raffle) = raffleService.edit(id, raffle)

    @DeleteMapping("{id}")
    fun delete(@PathVariable id: Long) = raffleService.remove(id)
}
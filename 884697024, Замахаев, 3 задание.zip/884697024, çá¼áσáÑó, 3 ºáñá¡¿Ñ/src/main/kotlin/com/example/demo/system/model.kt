package com.example.demo.system

import javax.persistence.*
import com.fasterxml.jackson.annotation.*

@Entity
@Table(name = "Промоакция")
data class Promo(
    @JsonProperty("name")
    @Column(name = "name", length = 200)
    val name: String = "",

    @JsonProperty("description")
    @Column(name = "description", length = 200)
    val description: String = "",

    @JsonProperty("prizes")
    @Column(name = "prizes", length = 50)
    val prizes: String = "",

    @JsonProperty("participants")
    @Column(name = "participants", length = 50)
    val participants: String = "",

    @Id
    @JsonProperty("id")
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Long = 0L
)
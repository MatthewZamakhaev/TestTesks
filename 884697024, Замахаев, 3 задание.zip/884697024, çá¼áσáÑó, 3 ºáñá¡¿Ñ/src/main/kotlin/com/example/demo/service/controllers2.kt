package com.example.demo.service

import com.example.demo.system.Participant

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("Приз")
class ParticipantController(private val participantService: ParticipantService) {
    @GetMapping
    fun index() = participantService.all()

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    fun create(@RequestBody participant: Participant) = participantService.add(participant)

    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.FOUND)
    fun read(@PathVariable id: Long) = participantService.get(id)

    @PutMapping("{id}")
    fun update(@PathVariable id: Long, @RequestBody participant: Participant) = participantService.edit(id, participant)

    @DeleteMapping("{id}")
    fun delete(@PathVariable id: Long) = participantService.remove(id)
}
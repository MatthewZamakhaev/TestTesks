package com.example.demo.service

import com.example.demo.system.*
import org.springframework.stereotype.Service

@Service
class RaffleService(private val raffleRepository: RaffleRepository) {
    fun all(): Iterable<Raffle> = raffleRepository.findAll()

    fun get(id: Long): Raffle = raffleRepository.findOne(id)

    fun add(product: Raffle): Raffle = raffleRepository.save(product)

    fun edit(id: Long, final: Raffle): Raffle = raffleRepository.save(final.copy(id = id))

    fun remove(id: Long) = raffleRepository.delete(id)
}
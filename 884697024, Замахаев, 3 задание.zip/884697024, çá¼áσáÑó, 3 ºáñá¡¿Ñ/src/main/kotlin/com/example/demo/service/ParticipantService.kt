package com.example.demo.service

import com.example.demo.system.*
import org.springframework.stereotype.Service

@Service
class ParticipantService(private val participantRepository: ParticipantRepository) {
    fun all(): Iterable<Participant> = participantRepository.findAll()

    fun get(id: Long): Participant = participantRepository.findOne(id)

    fun add(product: Participant): Participant = participantRepository.save(product)

    fun edit(id: Long, participant: Participant): Participant = participantRepository.save(participant.copy(id = id))

    fun remove(id: Long) = participantRepository.delete(id)
}
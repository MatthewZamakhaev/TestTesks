package com.example.demo.service

import com.example.demo.system.Prize

import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.*

@RestController
@RequestMapping("Приз")
class PrizeController(private val prizeService: PrizeService) {
    @GetMapping
    fun index() = prizeService.all()

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    fun create(@RequestBody prize: Prize) = prizeService.add(prize)

    @GetMapping("{id}")
    @ResponseStatus(HttpStatus.FOUND)
    fun read(@PathVariable id: Long) = prizeService.get(id)

    @PutMapping("{id}")
    fun update(@PathVariable id: Long, @RequestBody prize: Prize) = prizeService.edit(id, prize)

    @DeleteMapping("{id}")
    fun delete(@PathVariable id: Long) = prizeService.remove(id)
}
package com.example.demo.system

import javax.persistence.*
import com.fasterxml.jackson.annotation.*

@Entity
@Table(name = "Результат проведения розыгрыша")
data class Raffle(

    @JsonProperty("winner")
    @Column(name = "winner", length = 200)
    val winner: String = "",

    @JsonProperty("prize")
    @Column(name = "prize", length = 50)
    val prize: String = "",

    @Id
    @JsonProperty("id")
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    val id: Long = 0L

)
package com.example.demo.service

import com.example.demo.system.*
import org.springframework.stereotype.Service

@Service
class PromoService(private val promoRepository: PromoRepository) {
    fun all(): Iterable<Promo> = promoRepository.findAll()

    fun get(id: Long): Promo = promoRepository.findOne(id)

    fun add(product: Promo): Promo = promoRepository.save(product)

    fun edit(id: Long, promo: Promo): Promo = promoRepository.save(promo.copy(id = id))

    fun remove(id: Long) = promoRepository.delete(id)
}
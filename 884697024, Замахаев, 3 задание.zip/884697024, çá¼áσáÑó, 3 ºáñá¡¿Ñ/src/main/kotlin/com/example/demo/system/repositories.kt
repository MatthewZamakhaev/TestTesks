package com.example.demo.system

import org.springframework.data.repository.*

interface PromoRepository : CrudRepository<Promo, Long> {
    abstract fun findOne(id: Long): Promo
    abstract fun delete(id: Long)
}

interface PrizeRepository : CrudRepository<Prize, Long> {
    abstract fun findOne(id: Long): Prize
    abstract fun delete(id: Long)
}

interface ParticipantRepository : CrudRepository<Participant, Long> {
    abstract fun findOne(id: Long): Participant
    abstract fun delete(id: Long)
}

interface RaffleRepository : CrudRepository<Raffle, Long> {
    abstract fun findOne(id: Long): Raffle
    abstract fun delete(id: Long)
}